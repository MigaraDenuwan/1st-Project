function ewallet()
{
	alert("This payment method is currently unavailable");
}