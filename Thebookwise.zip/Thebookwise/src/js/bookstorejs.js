	document.getElementById("type1").innerHTML = "<br>Under Western Eyes <br> The Time of Their Lives";
	document.getElementById("type2").innerHTML = "<br>Ready Player One <br> Blood of the Broken";
	document.getElementById("type3").innerHTML = "<br>Law for the Common Man <br> Justice";
	document.getElementById("type4").innerHTML = "<br>Michelle Obama: A Biography <br> Abraham Lincoln: Volume two";
	document.getElementById("type5").innerHTML = "<br>English for All <br> French";
	document.getElementById("type6").innerHTML = "<br>A History of Sri Lanka <br> Four Lost Cities";
