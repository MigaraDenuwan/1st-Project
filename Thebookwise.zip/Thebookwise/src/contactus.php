<?php
	include_once 'header.php';
?>
		<hr class="line1">
	<div class= "Dhanuka3">
		<br>
			<br><h2><b><u>Contact Us</u></b></h2>
			<br><br><p>Need Help? Please feel free to contact us using the information below:</p>
		<br>
	
		<div class="picons">
			<img src="images/mail.png"><p>thebookwise@gmail.com</p><br><br><br>
			<img src="images/telephone1.png"><p>0760312456</p><br><br><br>
			<img src="images/telephone.png"><p>0114569874</p>
		</div>
	</div>
	
	<div class="contact">
		<h3><b>For Delivery Inquiries</b></h3>
		<br><p>Delivery Manager,<br>Mr K S M Sumanadasa<br>+94 760501236<br>sumanadasa@gmail.com</p><br><br><br><br>
		<h3><b>For Product Inquiries</b></h3>
		<br><p>Operations Manager,<br>Mr A M J Fernando<br>+94 778142365<br>fernando123@gmail.com</p>
	</div>

<?php
	include_once "footer.php";
?>